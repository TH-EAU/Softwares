﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Author : Théau NICOLAS
namespace KeyGen
{
    public partial class KEYGEN : Form
    {
        int size;
        int caze;
        int min;
        int maj;
        int num;
        String Keya;
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
        String filename;
        String AdText;


        public KEYGEN()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            Keya = "";// Reset de la clé
            int[] Key = new int[size];
            Random rnd = new Random();

            //Genere une clé au hazard selon la table ASCII
            

            for (int i=0;i<(size);i++)
            {
                int caze1 = rnd.Next(1, 4);//fonction random
                if (caze1 == 1)
                {
                    min = rnd.Next(65, 90);
                    Key[i] = min;
                    Keya = Keya + (char)Key[i];
                }
                if (caze1 == 2)
                {
                    caze = (maj = rnd.Next(97, 122));
                    Key[i] = caze;
                    Keya = Keya + (char)Key[i];
                }
                else
                {
                    caze = (num = rnd.Next(0, 9));
                    Key[i] = caze;
                    Keya = Keya + Key[i];
                } 
            }
            label1.Text = "KEY : " + Keya;
            
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = " "+ trackBar1.Value;
            size = trackBar1.Value;
        }

        private void SAVEButton_Click(object sender, EventArgs e)
        {
            System.IO.File.WriteAllText(@filename, "KEY : " + Keya + "  -   " + AddText.Text); // Ecrit dans le fichier
            //System.IO.File.WriteAllText(@filename, Keya); // Ecrit dans le fichier
            CheckLabel.Text = "Save done !";
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            // Ouvre la fenetre de sauvegarde
            // Definit le type de fichier a sauvegarder ici *.txt
            
            saveFileDialog1.Filter = "Text file|*.txt|Key file|*.key";
            saveFileDialog1.Title = "Save KEY";
            saveFileDialog1.ShowDialog();
            LocationBox.Text = saveFileDialog1.FileName;
            filename = saveFileDialog1.FileName;
        }
    }
}
