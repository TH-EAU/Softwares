﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Crypto
{
    public partial class Crypto : Form
    {
        String key;
        String File;
        String FileCrypt;
        OpenFileDialog OFD1 = new OpenFileDialog();
        SaveFileDialog SFD1 = new SaveFileDialog();
        OpenFileDialog OFD2 = new OpenFileDialog();
        SaveFileDialog SFD2 = new SaveFileDialog();


        public Crypto()
        {
            InitializeComponent();
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            OFD1.Filter = "Text File|*.txt";
            OFD1.Title = "Open file";
            OFD1.ShowDialog();
            LocationBox1.Text = OFD1.FileName;

            using (StreamReader reader = new StreamReader(OFD1.FileName))
            {
                File = reader.ReadToEnd();
                reader.Close();
                CodeBox.Text = File;
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SFD1.Filter = "Text file|*.txt|Cryto file|*.crypto";
            SFD1.Title = "Save file";
            SFD1.ShowDialog();
            

            System.IO.File.WriteAllText(@SFD1.FileName, FileCrypt);
        }

        private void ImportButton_Click(object sender, EventArgs e)
        {
            OFD2.Filter = "Key file|*.key|Text file|*.txt";
            OFD2.Title = "Open file";
            OFD2.ShowDialog();

            ImportKeyBox.Text = OFD2.FileName;

            
            using (StreamReader reader = new StreamReader(OFD2.FileName))
            {
                key = "KEY : " + reader.ReadToEnd();
                //key = "Md4JG75df5";
                reader.Close();
                LabelKEY.Text = key;
            }

        }

        private void CRYPT_Click(object sender, EventArgs e)
        {
            char[] CRYP = new char[File.Length];
            int Crypty;
            int Fil1;
            int Key1;
            int o;

            o = 0;
            int len = key.Length;
            for (int i=0; i<File.Length; i++)
            {
                Fil1 = (int)File[i];
                if (o >= len-1)
                 {
                     o = 0;
                 }
                
                o++;
                Key1 = (int)key[o];
                Crypty = Fil1 - Key1;
                CRYP[i] = (char)Crypty;
                FileCrypt = FileCrypt + CRYP[i];
            }      
        }
    }
}
