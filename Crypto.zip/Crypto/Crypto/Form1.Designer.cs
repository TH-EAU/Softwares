﻿namespace Crypto
{
    partial class Crypto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Crypto));
            this.LocationBox1 = new System.Windows.Forms.TextBox();
            this.BrowseButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.OpenLabel = new System.Windows.Forms.Label();
            this.SAVINGLabel = new System.Windows.Forms.Label();
            this.CRYPT = new System.Windows.Forms.Button();
            this.CodeBox = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.LabelKEY = new System.Windows.Forms.Label();
            this.ImportKeyBox = new System.Windows.Forms.TextBox();
            this.ImportButton = new System.Windows.Forms.Button();
            this.KEYLabel = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.CRYPTlabel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // LocationBox1
            // 
            this.LocationBox1.Location = new System.Drawing.Point(3, 45);
            this.LocationBox1.Name = "LocationBox1";
            this.LocationBox1.Size = new System.Drawing.Size(402, 20);
            this.LocationBox1.TabIndex = 0;
            // 
            // BrowseButton
            // 
            this.BrowseButton.Location = new System.Drawing.Point(411, 45);
            this.BrowseButton.Name = "BrowseButton";
            this.BrowseButton.Size = new System.Drawing.Size(102, 20);
            this.BrowseButton.TabIndex = 1;
            this.BrowseButton.Text = "Browse";
            this.BrowseButton.UseVisualStyleBackColor = true;
            this.BrowseButton.Click += new System.EventHandler(this.BrowseButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SaveButton.Location = new System.Drawing.Point(3, 45);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(122, 29);
            this.SaveButton.TabIndex = 2;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // OpenLabel
            // 
            this.OpenLabel.AutoSize = true;
            this.OpenLabel.BackColor = System.Drawing.Color.DimGray;
            this.OpenLabel.Font = new System.Drawing.Font("Bebas Neue", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenLabel.ForeColor = System.Drawing.Color.White;
            this.OpenLabel.Location = new System.Drawing.Point(3, 0);
            this.OpenLabel.Name = "OpenLabel";
            this.OpenLabel.Size = new System.Drawing.Size(122, 42);
            this.OpenLabel.TabIndex = 6;
            this.OpenLabel.Text = "OPEN FILE";
            // 
            // SAVINGLabel
            // 
            this.SAVINGLabel.AutoSize = true;
            this.SAVINGLabel.BackColor = System.Drawing.Color.DimGray;
            this.SAVINGLabel.Font = new System.Drawing.Font("Bebas Neue", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SAVINGLabel.ForeColor = System.Drawing.Color.White;
            this.SAVINGLabel.Location = new System.Drawing.Point(3, 0);
            this.SAVINGLabel.Name = "SAVINGLabel";
            this.SAVINGLabel.Size = new System.Drawing.Size(120, 42);
            this.SAVINGLabel.TabIndex = 8;
            this.SAVINGLabel.Text = "SAVE FILE";
            // 
            // CRYPT
            // 
            this.CRYPT.Font = new System.Drawing.Font("Xperia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CRYPT.ForeColor = System.Drawing.Color.Black;
            this.CRYPT.Location = new System.Drawing.Point(3, 45);
            this.CRYPT.Name = "CRYPT";
            this.CRYPT.Size = new System.Drawing.Size(134, 47);
            this.CRYPT.TabIndex = 12;
            this.CRYPT.Text = "CRYPT";
            this.CRYPT.UseVisualStyleBackColor = true;
            this.CRYPT.Click += new System.EventHandler(this.CRYPT_Click);
            // 
            // CodeBox
            // 
            this.CodeBox.Location = new System.Drawing.Point(3, 71);
            this.CodeBox.Multiline = true;
            this.CodeBox.Name = "CodeBox";
            this.CodeBox.Size = new System.Drawing.Size(402, 120);
            this.CodeBox.TabIndex = 13;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.DimGray;
            this.flowLayoutPanel2.Controls.Add(this.OpenLabel);
            this.flowLayoutPanel2.Controls.Add(this.LocationBox1);
            this.flowLayoutPanel2.Controls.Add(this.BrowseButton);
            this.flowLayoutPanel2.Controls.Add(this.CodeBox);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(12, 68);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(527, 203);
            this.flowLayoutPanel2.TabIndex = 15;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.BackColor = System.Drawing.Color.DimGray;
            this.flowLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.flowLayoutPanel3.Controls.Add(this.SAVINGLabel);
            this.flowLayoutPanel3.Controls.Add(this.SaveButton);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(411, 366);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(128, 88);
            this.flowLayoutPanel3.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-8, 352);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 119);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(527, 202);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // LabelKEY
            // 
            this.LabelKEY.AutoSize = true;
            this.LabelKEY.BackColor = System.Drawing.Color.DimGray;
            this.LabelKEY.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelKEY.ForeColor = System.Drawing.Color.White;
            this.LabelKEY.Location = new System.Drawing.Point(3, 42);
            this.LabelKEY.Name = "LabelKEY";
            this.LabelKEY.Size = new System.Drawing.Size(57, 24);
            this.LabelKEY.TabIndex = 11;
            this.LabelKEY.Text = "KEY :";
            // 
            // ImportKeyBox
            // 
            this.ImportKeyBox.Location = new System.Drawing.Point(68, 3);
            this.ImportKeyBox.Name = "ImportKeyBox";
            this.ImportKeyBox.Size = new System.Drawing.Size(238, 20);
            this.ImportKeyBox.TabIndex = 9;
            // 
            // ImportButton
            // 
            this.ImportButton.Location = new System.Drawing.Point(312, 3);
            this.ImportButton.Name = "ImportButton";
            this.ImportButton.Size = new System.Drawing.Size(59, 20);
            this.ImportButton.TabIndex = 10;
            this.ImportButton.Text = "Import";
            this.ImportButton.UseVisualStyleBackColor = true;
            this.ImportButton.Click += new System.EventHandler(this.ImportButton_Click);
            // 
            // KEYLabel
            // 
            this.KEYLabel.AutoSize = true;
            this.KEYLabel.BackColor = System.Drawing.Color.DimGray;
            this.KEYLabel.Font = new System.Drawing.Font("Bebas Neue", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KEYLabel.ForeColor = System.Drawing.Color.White;
            this.KEYLabel.Location = new System.Drawing.Point(3, 0);
            this.KEYLabel.Name = "KEYLabel";
            this.KEYLabel.Size = new System.Drawing.Size(59, 42);
            this.KEYLabel.TabIndex = 7;
            this.KEYLabel.Text = "KEY";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.DimGray;
            this.flowLayoutPanel1.Controls.Add(this.KEYLabel);
            this.flowLayoutPanel1.Controls.Add(this.ImportKeyBox);
            this.flowLayoutPanel1.Controls.Add(this.ImportButton);
            this.flowLayoutPanel1.Controls.Add(this.LabelKEY);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(159, 277);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(380, 83);
            this.flowLayoutPanel1.TabIndex = 14;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackColor = System.Drawing.Color.DimGray;
            this.flowLayoutPanel4.Controls.Add(this.CRYPTlabel);
            this.flowLayoutPanel4.Controls.Add(this.CRYPT);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(11, 277);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(142, 98);
            this.flowLayoutPanel4.TabIndex = 19;
            // 
            // CRYPTlabel
            // 
            this.CRYPTlabel.AutoSize = true;
            this.CRYPTlabel.Font = new System.Drawing.Font("Bebas Neue", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CRYPTlabel.ForeColor = System.Drawing.Color.White;
            this.CRYPTlabel.Location = new System.Drawing.Point(3, 0);
            this.CRYPTlabel.Name = "CRYPTlabel";
            this.CRYPTlabel.Size = new System.Drawing.Size(134, 42);
            this.CRYPTlabel.TabIndex = 13;
            this.CRYPTlabel.Text = "CRYPT FILE";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(169, 366);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(200, 200);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // Crypto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(68)))), ((int)(((byte)(89)))));
            this.ClientSize = new System.Drawing.Size(561, 466);
            this.Controls.Add(this.flowLayoutPanel4);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Crypto";
            this.Text = " CRYPTO";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox LocationBox1;
        private System.Windows.Forms.Button BrowseButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Label OpenLabel;
        private System.Windows.Forms.Label SAVINGLabel;
        private System.Windows.Forms.Button CRYPT;
        private System.Windows.Forms.TextBox CodeBox;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label LabelKEY;
        private System.Windows.Forms.TextBox ImportKeyBox;
        private System.Windows.Forms.Button ImportButton;
        private System.Windows.Forms.Label KEYLabel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Label CRYPTlabel;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

